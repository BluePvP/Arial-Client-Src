package me.kaimson.arialclient.gui;

public class GuiUtils extends GLUtils {

    public final static GuiUtils INSTANCE = new GuiUtils();

}
