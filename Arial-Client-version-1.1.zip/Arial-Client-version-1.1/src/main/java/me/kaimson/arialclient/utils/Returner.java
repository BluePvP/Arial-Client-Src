package me.kaimson.arialclient.utils;

import lombok.Getter;
import lombok.Setter;

public class Returner {

    @Getter @Setter
    private boolean cancelled;

}
