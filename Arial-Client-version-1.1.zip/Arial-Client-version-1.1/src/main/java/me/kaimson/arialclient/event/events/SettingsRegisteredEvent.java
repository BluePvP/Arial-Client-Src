package me.kaimson.arialclient.event.events;

import me.kaimson.arialclient.event.Event;

public class SettingsRegisteredEvent extends Event {
}
