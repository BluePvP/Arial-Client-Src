package me.kaimson.arialclient.event.events;

import me.kaimson.arialclient.event.Event;

public class InitializationEvent extends Event {

    public static class Pre extends InitializationEvent {

    }

    public static class Post extends InitializationEvent {

    }

}
