package me.kaimson.arialclient.event;

public class Event
{
}
