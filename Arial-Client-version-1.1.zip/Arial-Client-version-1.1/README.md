# Arial Client
1.8.9 | Version 1.1

## Disclaimer
This repo is for educational purposes only!

The purpose of this repo is to learn how Minecraft clients work.
